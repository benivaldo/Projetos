--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_unidade_cad_produto;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_tipo_produto_cad_produto;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_subgrupo_cad_produto;
ALTER TABLE ONLY public.cad_grupo DROP CONSTRAINT cad_secao_cad_grupo;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_ipi_cad_produto_16;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_ipi_cad_produto;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_icms_cad_produto_8;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_icms_cad_produto_6;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_icms_cad_produto;
ALTER TABLE ONLY public.cad_subgrupo DROP CONSTRAINT cad_grupo_cad_subgrupo;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_fornecedor_cad_produto;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_ean_cad_produto;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_cofins_cad_produto_15;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_cofins_cad_produto;
ALTER TABLE ONLY public.cad_ean DROP CONSTRAINT sku;
ALTER TABLE ONLY public.cad_icms DROP CONSTRAINT descricao11;
ALTER TABLE ONLY public.cad_unidade DROP CONSTRAINT descricao1;
ALTER TABLE ONLY public.tab_tipo_produto DROP CONSTRAINT descricao;
ALTER TABLE ONLY public.cad_unidade DROP CONSTRAINT codigo31;
ALTER TABLE ONLY public.cad_cofins DROP CONSTRAINT codigo12;
ALTER TABLE ONLY public.tab_tipo_produto DROP CONSTRAINT codigo1;
ALTER TABLE ONLY public.cad_pis DROP CONSTRAINT codigo;
ALTER TABLE ONLY public.cad_produto DROP CONSTRAINT cad_produto_pkey;
ALTER TABLE ONLY public.cad_ncm DROP CONSTRAINT cad_ncm_pkey;
ALTER TABLE ONLY public.tab_origem DROP CONSTRAINT "PK_tab_origem";
ALTER TABLE ONLY public.tab_estado DROP CONSTRAINT "PK_tab_estado";
ALTER TABLE ONLY public.tab_cst_pis DROP CONSTRAINT "PK_tab_cst_pis";
ALTER TABLE ONLY public.tab_cst_ipi DROP CONSTRAINT "PK_tab_cst_ipi";
ALTER TABLE ONLY public.tab_cst_icms DROP CONSTRAINT "PK_tab_cst_icms";
ALTER TABLE ONLY public.tab_cst_cofins DROP CONSTRAINT "PK_tab_cst_cofins";
ALTER TABLE ONLY public.tab_csosn DROP CONSTRAINT "PK_tab_csosn";
ALTER TABLE ONLY public.tab_cidade DROP CONSTRAINT "PK_tab_cidade";
ALTER TABLE ONLY public.tab_cest DROP CONSTRAINT "PK_tab_cest";
ALTER TABLE ONLY public.cad_unidade DROP CONSTRAINT "PK_cad_unidade";
ALTER TABLE ONLY public.tab_tipo_produto DROP CONSTRAINT "PK_cad_tipo_produto";
ALTER TABLE ONLY public.cad_subgrupo DROP CONSTRAINT "PK_cad_subgrupo";
ALTER TABLE ONLY public.cad_secao DROP CONSTRAINT "PK_cad_secao";
ALTER TABLE ONLY public.cad_pis DROP CONSTRAINT "PK_cad_pis";
ALTER TABLE ONLY public.cad_loja DROP CONSTRAINT "PK_cad_loja";
ALTER TABLE ONLY public.cad_ipi DROP CONSTRAINT "PK_cad_ipi";
ALTER TABLE ONLY public.cad_icms DROP CONSTRAINT "PK_cad_icms_nf";
ALTER TABLE ONLY public.cad_grupo DROP CONSTRAINT "PK_cad_grupo";
ALTER TABLE ONLY public.cad_fornecedor DROP CONSTRAINT "PK_cad_fornecedor";
ALTER TABLE ONLY public.cad_ean DROP CONSTRAINT "PK_cad_ean";
ALTER TABLE ONLY public.tab_crt DROP CONSTRAINT "PK_cad_crt";
ALTER TABLE ONLY public.cad_cofins DROP CONSTRAINT "PK_cad_cofins";
ALTER TABLE ONLY public.cad_pis DROP CONSTRAINT "Attribute21";
ALTER TABLE ONLY public.cad_cofins DROP CONSTRAINT "Attribute2";
ALTER TABLE ONLY public.cad_secao DROP CONSTRAINT "Attribute1";
ALTER TABLE public.tab_tipo_produto ALTER COLUMN tipo_produto_id DROP DEFAULT;
ALTER TABLE public.tab_origem ALTER COLUMN origem_id DROP DEFAULT;
ALTER TABLE public.tab_estado ALTER COLUMN estado_id DROP DEFAULT;
ALTER TABLE public.tab_cst_pis ALTER COLUMN cst_pis_id DROP DEFAULT;
ALTER TABLE public.tab_cst_ipi ALTER COLUMN cst_ipi_id DROP DEFAULT;
ALTER TABLE public.tab_cst_icms ALTER COLUMN cst_icms_id DROP DEFAULT;
ALTER TABLE public.tab_cst_cofins ALTER COLUMN cst_cofins_id DROP DEFAULT;
ALTER TABLE public.tab_csosn ALTER COLUMN csosn_id DROP DEFAULT;
ALTER TABLE public.tab_crt ALTER COLUMN crt_id DROP DEFAULT;
ALTER TABLE public.tab_cidade ALTER COLUMN cidade_id DROP DEFAULT;
ALTER TABLE public.tab_cest ALTER COLUMN cest_id DROP DEFAULT;
ALTER TABLE public.cad_unidade ALTER COLUMN unidade_id DROP DEFAULT;
ALTER TABLE public.cad_subgrupo ALTER COLUMN subgrupo_id DROP DEFAULT;
ALTER TABLE public.cad_secao ALTER COLUMN secao_id DROP DEFAULT;
ALTER TABLE public.cad_produto ALTER COLUMN produto_id DROP DEFAULT;
ALTER TABLE public.cad_pis ALTER COLUMN pis_id DROP DEFAULT;
ALTER TABLE public.cad_ncm ALTER COLUMN ncm_id DROP DEFAULT;
ALTER TABLE public.cad_loja ALTER COLUMN loja_id DROP DEFAULT;
ALTER TABLE public.cad_ipi ALTER COLUMN ipi_id DROP DEFAULT;
ALTER TABLE public.cad_icms ALTER COLUMN icms_id DROP DEFAULT;
ALTER TABLE public.cad_grupo ALTER COLUMN grupo_id DROP DEFAULT;
ALTER TABLE public.cad_fornecedor ALTER COLUMN fornecedor_id DROP DEFAULT;
ALTER TABLE public.cad_ean ALTER COLUMN sku_id DROP DEFAULT;
ALTER TABLE public.cad_cofins ALTER COLUMN cofins_id DROP DEFAULT;
ALTER TABLE public.album ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.tab_tipo_produto_tipo_produto_id_seq;
DROP TABLE public.tab_tipo_produto;
DROP SEQUENCE public.tab_origem_origem_id_seq;
DROP TABLE public.tab_origem;
DROP SEQUENCE public.tab_estado_estado_id_seq;
DROP TABLE public.tab_estado;
DROP SEQUENCE public.tab_cst_pis_cst_pis_id_seq;
DROP TABLE public.tab_cst_pis;
DROP SEQUENCE public.tab_cst_ipi_cst_ipi_id_seq;
DROP TABLE public.tab_cst_ipi;
DROP SEQUENCE public.tab_cst_icms_cst_icms_id_seq;
DROP TABLE public.tab_cst_icms;
DROP SEQUENCE public.tab_cst_cofins_cst_cofins_id_seq;
DROP TABLE public.tab_cst_cofins;
DROP SEQUENCE public.tab_csosn_csosn_id_seq;
DROP TABLE public.tab_csosn;
DROP SEQUENCE public.tab_crt_crt_id_seq;
DROP TABLE public.tab_crt;
DROP SEQUENCE public.tab_cidade_cidade_id_seq;
DROP TABLE public.tab_cidade;
DROP SEQUENCE public.tab_cest_cest_id_seq;
DROP TABLE public.tab_cest;
DROP SEQUENCE public.plu_unidade;
DROP SEQUENCE public.cad_unidade_unidade_id_seq;
DROP TABLE public.cad_unidade;
DROP SEQUENCE public.cad_subgrupo_subgrupo_id_seq;
DROP TABLE public.cad_subgrupo;
DROP SEQUENCE public.cad_secao_secao_id_seq;
DROP TABLE public.cad_secao;
DROP SEQUENCE public.cad_produto_produto_id_seq;
DROP TABLE public.cad_produto;
DROP SEQUENCE public.cad_pis_pis_id_seq;
DROP TABLE public.cad_pis;
DROP SEQUENCE public.cad_ncm_ncm_id_seq;
DROP TABLE public.cad_ncm;
DROP SEQUENCE public.cad_loja_loja_id_seq;
DROP TABLE public.cad_loja;
DROP SEQUENCE public.cad_ipi_ipi_id_seq;
DROP TABLE public.cad_ipi;
DROP SEQUENCE public.cad_icms_icms_id_seq;
DROP TABLE public.cad_icms;
DROP SEQUENCE public.cad_grupo_grupo_id_seq;
DROP TABLE public.cad_grupo;
DROP SEQUENCE public.cad_fornecedor_fornecedor_id_seq;
DROP TABLE public.cad_fornecedor;
DROP SEQUENCE public.cad_ean_sku_id_seq;
DROP TABLE public.cad_ean;
DROP SEQUENCE public.cad_cofins_cofins_id_seq;
DROP TABLE public.cad_cofins;
DROP SEQUENCE public.album_id_seq;
DROP TABLE public.album;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: album; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE album (
    id integer NOT NULL,
    artist character varying(100) NOT NULL,
    title character varying(100) NOT NULL
);


ALTER TABLE album OWNER TO postgres;

--
-- Name: album_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE album_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE album_id_seq OWNER TO postgres;

--
-- Name: album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE album_id_seq OWNED BY album.id;


--
-- Name: cad_cofins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_cofins (
    cofins_id smallint NOT NULL,
    codigo character(2) NOT NULL,
    descricao character varying(50) NOT NULL,
    aliquota numeric(4,3),
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_cofins OWNER TO postgres;

--
-- Name: COLUMN cad_cofins.cofins_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.cofins_id IS 'Chave primaria';


--
-- Name: COLUMN cad_cofins.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.codigo IS 'Codigo cofins';


--
-- Name: COLUMN cad_cofins.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.descricao IS 'Descrição do cst de cofins';


--
-- Name: COLUMN cad_cofins.aliquota; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.aliquota IS 'Aliquota de cofins';


--
-- Name: COLUMN cad_cofins.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_cofins.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_cofins.data_altera IS 'Data de alteração';


--
-- Name: cad_cofins_cofins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_cofins_cofins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_cofins_cofins_id_seq OWNER TO postgres;

--
-- Name: cad_cofins_cofins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_cofins_cofins_id_seq OWNED BY cad_cofins.cofins_id;


--
-- Name: cad_ean; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_ean (
    sku_id integer NOT NULL,
    sku character varying(14) NOT NULL,
    plu_id integer NOT NULL,
    ativo boolean NOT NULL,
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_ean OWNER TO postgres;

--
-- Name: COLUMN cad_ean.sku_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.sku_id IS 'Chave primaria';


--
-- Name: COLUMN cad_ean.sku; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.sku IS 'Codigo de barras do plu';


--
-- Name: COLUMN cad_ean.plu_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.plu_id IS 'Plu associado ao codigo de barras';


--
-- Name: COLUMN cad_ean.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.ativo IS 'Sku em uso';


--
-- Name: COLUMN cad_ean.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_ean.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ean.data_altera IS 'Data de alteração';


--
-- Name: cad_ean_sku_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_ean_sku_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_ean_sku_id_seq OWNER TO postgres;

--
-- Name: cad_ean_sku_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_ean_sku_id_seq OWNED BY cad_ean.sku_id;


--
-- Name: cad_fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_fornecedor (
    fornecedor_id integer NOT NULL,
    cnpj_cpf character varying(14) NOT NULL,
    ie_rg character varying(20) NOT NULL,
    ie_st character varying(20),
    razao character varying(60) NOT NULL,
    fantasia character varying(40) NOT NULL,
    crt smallint,
    cep character(8),
    logradouro character varying(60),
    numero smallint,
    complemento character varying(20),
    bairro character varying(60),
    cidade integer,
    uf smallint,
    contato character varying(60),
    observacao character varying(255),
    email character varying(50),
    suframa character varying(20),
    centro_custo_id smallint,
    telefone character(10),
    ramal character varying(10),
    celular character varying(11),
    ativo boolean NOT NULL,
    data_cadastro date,
    data_altera date,
    tipo character(1)
);


ALTER TABLE cad_fornecedor OWNER TO postgres;

--
-- Name: COLUMN cad_fornecedor.fornecedor_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.fornecedor_id IS 'Chave primaria, o valor da chave de ser alteradom para iniciar em 1';


--
-- Name: COLUMN cad_fornecedor.cnpj_cpf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.cnpj_cpf IS 'Código do cnpj/cpf';


--
-- Name: COLUMN cad_fornecedor.ie_rg; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.ie_rg IS 'Inscrição estadual/Rg';


--
-- Name: COLUMN cad_fornecedor.ie_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.ie_st IS 'Inscrição estadual substituição triubutaria';


--
-- Name: COLUMN cad_fornecedor.razao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.razao IS 'Razão social';


--
-- Name: COLUMN cad_fornecedor.fantasia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.fantasia IS 'Nome fantasia';


--
-- Name: COLUMN cad_fornecedor.crt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.crt IS 'Código do regime tributário';


--
-- Name: COLUMN cad_fornecedor.cep; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.cep IS 'Cep do endereço do fornecedor';


--
-- Name: COLUMN cad_fornecedor.logradouro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.logradouro IS 'Enderço do fornecedor';


--
-- Name: COLUMN cad_fornecedor.numero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.numero IS 'Numero do endereço do fornecedor';


--
-- Name: COLUMN cad_fornecedor.complemento; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.complemento IS 'Nome do complemento do endereço';


--
-- Name: COLUMN cad_fornecedor.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.bairro IS 'Nome do bairro do endereço do fornecedor';


--
-- Name: COLUMN cad_fornecedor.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.cidade IS 'Codigo da cidade do fornecedor';


--
-- Name: COLUMN cad_fornecedor.uf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.uf IS 'Código da unidade federal do fornecedor';


--
-- Name: COLUMN cad_fornecedor.contato; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.contato IS 'Nome do contato do fornecedor';


--
-- Name: COLUMN cad_fornecedor.observacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.observacao IS 'Observação sobre o fornecedor';


--
-- Name: COLUMN cad_fornecedor.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.email IS 'email do fornecedor';


--
-- Name: COLUMN cad_fornecedor.suframa; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.suframa IS 'Inscrição no suframa';


--
-- Name: COLUMN cad_fornecedor.centro_custo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.centro_custo_id IS 'Centro de custo';


--
-- Name: COLUMN cad_fornecedor.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.telefone IS 'Numero do telefone';


--
-- Name: COLUMN cad_fornecedor.ramal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.ramal IS 'Número do ramal';


--
-- Name: COLUMN cad_fornecedor.celular; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.celular IS 'Número do celular';


--
-- Name: COLUMN cad_fornecedor.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.ativo IS 'Ativo sim/não';


--
-- Name: COLUMN cad_fornecedor.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_fornecedor.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.data_altera IS 'Data de alteração';


--
-- Name: COLUMN cad_fornecedor.tipo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_fornecedor.tipo IS 'Tipo de pessoa  j:  juridica, f: fisica';


--
-- Name: cad_fornecedor_fornecedor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_fornecedor_fornecedor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_fornecedor_fornecedor_id_seq OWNER TO postgres;

--
-- Name: cad_fornecedor_fornecedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_fornecedor_fornecedor_id_seq OWNED BY cad_fornecedor.fornecedor_id;


--
-- Name: cad_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_grupo (
    grupo_id smallint NOT NULL,
    descricao character varying(50) NOT NULL,
    secao_id smallint NOT NULL,
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_grupo OWNER TO postgres;

--
-- Name: COLUMN cad_grupo.grupo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_grupo.grupo_id IS 'Chave primaria do grupo';


--
-- Name: COLUMN cad_grupo.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_grupo.descricao IS 'Descricao do grupo';


--
-- Name: COLUMN cad_grupo.secao_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_grupo.secao_id IS 'Seção ao qual o grupo pertence';


--
-- Name: COLUMN cad_grupo.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_grupo.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_grupo.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_grupo.data_altera IS 'Data de alteração';


--
-- Name: cad_grupo_grupo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_grupo_grupo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_grupo_grupo_id_seq OWNER TO postgres;

--
-- Name: cad_grupo_grupo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_grupo_grupo_id_seq OWNED BY cad_grupo.grupo_id;


--
-- Name: cad_icms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_icms (
    icms_id integer NOT NULL,
    cst character(2),
    descricao character varying(50) NOT NULL,
    tributacao character varying(2),
    csosn character(3),
    origem character(1) NOT NULL,
    aliquota numeric(4,2) NOT NULL,
    base numeric(10,2),
    mod_icms smallint,
    aliquota_st numeric(4,2),
    base_st numeric(10,2),
    mod_icms_st smallint,
    uso smallint NOT NULL,
    texto_nf_id character varying(255),
    cod_tributacao_pdv character varying(4),
    cfop character(5),
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_icms OWNER TO postgres;

--
-- Name: COLUMN cad_icms.icms_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.icms_id IS 'Chave primaria';


--
-- Name: COLUMN cad_icms.cst; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.cst IS 'CST de icms do produto';


--
-- Name: COLUMN cad_icms.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.descricao IS 'Descrição do icms';


--
-- Name: COLUMN cad_icms.tributacao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.tributacao IS 'Codigo da tributação T: tributado, NT: não tributado, ST: situação tributária, I: isento, D: diferido, S: substituição tributaria';


--
-- Name: COLUMN cad_icms.csosn; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.csosn IS 'Código para simples nacional';


--
-- Name: COLUMN cad_icms.origem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.origem IS 'Origem do produto';


--
-- Name: COLUMN cad_icms.aliquota; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.aliquota IS 'Aliquota de icms';


--
-- Name: COLUMN cad_icms.base; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.base IS 'Base de redução';


--
-- Name: COLUMN cad_icms.mod_icms; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.mod_icms IS 'Modalidade do icms, para efeito de calculo na emissão de nota';


--
-- Name: COLUMN cad_icms.aliquota_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.aliquota_st IS 'Aliquota de ST';


--
-- Name: COLUMN cad_icms.base_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.base_st IS 'Base do ST';


--
-- Name: COLUMN cad_icms.mod_icms_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.mod_icms_st IS 'Modalidade do icms st';


--
-- Name: COLUMN cad_icms.uso; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.uso IS 'Define o uso para entrado ou saida. 1: Entrada e Saida, 2: Entrada, 3: Saida, 4: Pdv
';


--
-- Name: COLUMN cad_icms.texto_nf_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.texto_nf_id IS 'Código do texto a ser usado na emissão da nota';


--
-- Name: COLUMN cad_icms.cod_tributacao_pdv; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.cod_tributacao_pdv IS 'Codigo de tributação usado no ecf.';


--
-- Name: COLUMN cad_icms.cfop; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.cfop IS 'Cfop para uso na saida de venda pdv, usado no sped icms';


--
-- Name: COLUMN cad_icms.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_icms.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_icms.data_altera IS 'Data de alteração';


--
-- Name: cad_icms_icms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_icms_icms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_icms_icms_id_seq OWNER TO postgres;

--
-- Name: cad_icms_icms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_icms_icms_id_seq OWNED BY cad_icms.icms_id;


--
-- Name: cad_ipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_ipi (
    ipi_id smallint NOT NULL,
    codigo character(2),
    descricao character varying(60) NOT NULL,
    aliquota numeric(4,2),
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_ipi OWNER TO postgres;

--
-- Name: COLUMN cad_ipi.ipi_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.ipi_id IS 'Chave primaria';


--
-- Name: COLUMN cad_ipi.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.codigo IS 'Codigo da situção usado(IPI)';


--
-- Name: COLUMN cad_ipi.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.descricao IS 'Descrição do IPI';


--
-- Name: COLUMN cad_ipi.aliquota; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.aliquota IS 'Aliquota de IPI';


--
-- Name: COLUMN cad_ipi.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.data_cadastro IS 'Dada de cadastro';


--
-- Name: COLUMN cad_ipi.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ipi.data_altera IS 'Data de alteração';


--
-- Name: cad_ipi_ipi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_ipi_ipi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_ipi_ipi_id_seq OWNER TO postgres;

--
-- Name: cad_ipi_ipi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_ipi_ipi_id_seq OWNED BY cad_ipi.ipi_id;


--
-- Name: cad_loja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_loja (
    loja_id smallint NOT NULL,
    razao character varying(60) NOT NULL,
    fantasia character(30) NOT NULL,
    cnpj character(13) NOT NULL,
    ie character varying(12) NOT NULL,
    telefone character(8),
    logradouro character varying(60) NOT NULL,
    numero smallint,
    bairro character varying(60) NOT NULL,
    municipio smallint NOT NULL,
    cep character(8) NOT NULL,
    estado smallint NOT NULL,
    num_loja smallint NOT NULL,
    mix character varying(20) NOT NULL,
    crt smallint NOT NULL,
    data_cadastro date NOT NULL,
    data_altera date
);


ALTER TABLE cad_loja OWNER TO postgres;

--
-- Name: COLUMN cad_loja.loja_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.loja_id IS 'Chave primaria';


--
-- Name: COLUMN cad_loja.razao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.razao IS 'Razão social';


--
-- Name: COLUMN cad_loja.fantasia; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.fantasia IS 'Nome fantasia';


--
-- Name: COLUMN cad_loja.cnpj; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.cnpj IS 'Cnpj da loja';


--
-- Name: COLUMN cad_loja.ie; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.ie IS 'Inscrição estadual da loja';


--
-- Name: COLUMN cad_loja.telefone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.telefone IS 'Número do telefone da loja';


--
-- Name: COLUMN cad_loja.logradouro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.logradouro IS 'Endereço da loja

';


--
-- Name: COLUMN cad_loja.numero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.numero IS 'Numero do endereço da loja';


--
-- Name: COLUMN cad_loja.bairro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.bairro IS 'Bairro da loja';


--
-- Name: COLUMN cad_loja.cep; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.cep IS 'Código do cep da loja';


--
-- Name: COLUMN cad_loja.num_loja; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.num_loja IS 'Numero da loja';


--
-- Name: COLUMN cad_loja.mix; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.mix IS 'Nome da tabela mix de loja';


--
-- Name: COLUMN cad_loja.crt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.crt IS 'Código do regime tributário';


--
-- Name: COLUMN cad_loja.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_loja.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_loja.data_altera IS 'Data de alteração';


--
-- Name: cad_loja_loja_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_loja_loja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_loja_loja_id_seq OWNER TO postgres;

--
-- Name: cad_loja_loja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_loja_loja_id_seq OWNED BY cad_loja.loja_id;


--
-- Name: cad_ncm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_ncm (
    codigo character varying(20) NOT NULL,
    descricao character varying(255) NOT NULL,
    ex_tipi smallint,
    nat character(3),
    pis_entrada_id smallint,
    pis_saida_id smallint,
    cofins_entrada_id smallint,
    cofins_saida_id smallint,
    icms_pdv_id integer,
    icms_nf_entrada_id integer,
    icms_nf_saida_id integer,
    ipi_entrada_id smallint,
    ipi_saida_id smallint,
    mva_st numeric(10,3),
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date,
    cest_id smallint,
    ncm character(8),
    ncm_id bigint NOT NULL
);


ALTER TABLE cad_ncm OWNER TO postgres;

--
-- Name: COLUMN cad_ncm.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.codigo IS 'Descrição de uso';


--
-- Name: COLUMN cad_ncm.ex_tipi; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.ex_tipi IS 'Código da exeção da tipi';


--
-- Name: COLUMN cad_ncm.nat; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.nat IS 'Código da natureza da operação';


--
-- Name: COLUMN cad_ncm.pis_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.pis_entrada_id IS 'Pis para venda';


--
-- Name: COLUMN cad_ncm.pis_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.pis_saida_id IS 'Pis de saida';


--
-- Name: COLUMN cad_ncm.cofins_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.cofins_entrada_id IS 'Cofins de entrada';


--
-- Name: COLUMN cad_ncm.cofins_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.cofins_saida_id IS 'Cofins de saida';


--
-- Name: COLUMN cad_ncm.icms_pdv_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.icms_pdv_id IS 'icms para ecf
';


--
-- Name: COLUMN cad_ncm.icms_nf_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.icms_nf_entrada_id IS 'Icms de entrada para nf';


--
-- Name: COLUMN cad_ncm.icms_nf_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.icms_nf_saida_id IS 'Icms de saida para nf';


--
-- Name: COLUMN cad_ncm.ipi_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.ipi_entrada_id IS 'IPI de entrada';


--
-- Name: COLUMN cad_ncm.ipi_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.ipi_saida_id IS 'Ipi de saida';


--
-- Name: COLUMN cad_ncm.mva_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.mva_st IS 'Valor do mv quando for st';


--
-- Name: COLUMN cad_ncm.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_ncm.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.data_altera IS 'Data de alteração';


--
-- Name: COLUMN cad_ncm.ncm; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_ncm.ncm IS 'Código ncm';


--
-- Name: cad_ncm_ncm_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_ncm_ncm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_ncm_ncm_id_seq OWNER TO postgres;

--
-- Name: cad_ncm_ncm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_ncm_ncm_id_seq OWNED BY cad_ncm.ncm_id;


--
-- Name: cad_pis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_pis (
    pis_id smallint NOT NULL,
    codigo character(2) NOT NULL,
    descricao character varying(50) NOT NULL,
    aliquota numeric(4,3),
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_pis OWNER TO postgres;

--
-- Name: COLUMN cad_pis.pis_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.pis_id IS 'Chave primaria';


--
-- Name: COLUMN cad_pis.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.codigo IS 'Codigo do cst de pis';


--
-- Name: COLUMN cad_pis.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.descricao IS 'descrição do cst de pis';


--
-- Name: COLUMN cad_pis.aliquota; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.aliquota IS 'Aliquota de pis';


--
-- Name: COLUMN cad_pis.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_pis.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_pis.data_altera IS 'Data de alteração';


--
-- Name: cad_pis_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_pis_pis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_pis_pis_id_seq OWNER TO postgres;

--
-- Name: cad_pis_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_pis_pis_id_seq OWNED BY cad_pis.pis_id;


--
-- Name: cad_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_produto (
    produto_id bigint NOT NULL,
    plu integer NOT NULL,
    sku_id integer,
    ativo boolean NOT NULL,
    descricao character varying(60) NOT NULL,
    desc_resumida character varying(22) NOT NULL,
    ncm_id integer NOT NULL,
    secao_id smallint NOT NULL,
    grupo_id smallint NOT NULL,
    subgrupo_id smallint NOT NULL,
    fornecedor_id integer,
    grade_id integer,
    embalagem_id smallint,
    unidade_id smallint NOT NULL,
    tipo_produto_id smallint NOT NULL,
    icms_nf_entrada_id integer NOT NULL,
    icms_nf_saida_id integer NOT NULL,
    icms_pdv_id integer NOT NULL,
    pis_entrada_id smallint NOT NULL,
    pis_saida_id smallint NOT NULL,
    cofins_entrada_id smallint NOT NULL,
    cofins_saida_id smallint NOT NULL,
    ipi_entrada_id smallint,
    ipi_saida_id smallint,
    mva_st numeric(10,3),
    peso_liquido numeric(10,3),
    peso_bruto numeric(10,3),
    estoque_min numeric(10,3),
    estoque_ideal numeric(10,3),
    curva_abc boolean,
    carga_pdv boolean,
    prod_balanca boolean,
    permite_frac boolean,
    permite_preco boolean,
    data_cadastro date DEFAULT now() NOT NULL,
    cest_id smallint,
    cod_fornecedor character varying(20),
    ref_fornecedor character varying(20),
    data_altera date
);


ALTER TABLE cad_produto OWNER TO postgres;

--
-- Name: COLUMN cad_produto.produto_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.produto_id IS 'Chave gerada sequencialmente';


--
-- Name: COLUMN cad_produto.plu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.plu IS 'Codigo interno do produto';


--
-- Name: COLUMN cad_produto.sku_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.sku_id IS 'Chave de referencia do codigo de barras utilizado';


--
-- Name: COLUMN cad_produto.ativo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.ativo IS 'Situacao do produto';


--
-- Name: COLUMN cad_produto.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.descricao IS 'Descricao do produto';


--
-- Name: COLUMN cad_produto.desc_resumida; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.desc_resumida IS 'Descricao resumida para ser usada no pdv e balanca';


--
-- Name: COLUMN cad_produto.ncm_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.ncm_id IS 'Classificacao fiscal do produto';


--
-- Name: COLUMN cad_produto.secao_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.secao_id IS 'Chave de referencia da secao utilizada';


--
-- Name: COLUMN cad_produto.grupo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.grupo_id IS 'Chave de referencia do grupo utilizado';


--
-- Name: COLUMN cad_produto.subgrupo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.subgrupo_id IS 'Chave de referencia di subgrupo utilizado';


--
-- Name: COLUMN cad_produto.grade_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.grade_id IS 'Chave da grade de produtos utilizada';


--
-- Name: COLUMN cad_produto.embalagem_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.embalagem_id IS 'Embalagem do produto';


--
-- Name: COLUMN cad_produto.unidade_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.unidade_id IS 'Chave de referencia da unidade utilizada';


--
-- Name: COLUMN cad_produto.tipo_produto_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.tipo_produto_id IS 'Tipo de produto utilizado conforme tabela de tipos de produto do sped';


--
-- Name: COLUMN cad_produto.icms_nf_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.icms_nf_entrada_id IS 'Chave de referecia do cst de icms utilizado para entrada de nota';


--
-- Name: COLUMN cad_produto.icms_pdv_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.icms_pdv_id IS 'Tributacao para o pdv';


--
-- Name: COLUMN cad_produto.pis_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.pis_entrada_id IS 'Pis de entrada';


--
-- Name: COLUMN cad_produto.pis_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.pis_saida_id IS 'Pis de saida';


--
-- Name: COLUMN cad_produto.cofins_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.cofins_entrada_id IS 'Cofins de entrada';


--
-- Name: COLUMN cad_produto.cofins_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.cofins_saida_id IS 'Cofins de saida';


--
-- Name: COLUMN cad_produto.ipi_entrada_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.ipi_entrada_id IS 'Ipi de entrada';


--
-- Name: COLUMN cad_produto.ipi_saida_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.ipi_saida_id IS 'Ipi de saida';


--
-- Name: COLUMN cad_produto.mva_st; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.mva_st IS 'Valor do mva quando for st';


--
-- Name: COLUMN cad_produto.peso_liquido; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.peso_liquido IS 'Peso líquido da mercadoria a ser usado na emissão de nota';


--
-- Name: COLUMN cad_produto.peso_bruto; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.peso_bruto IS 'Peso bruto do produto a ser usado na emissao de nota';


--
-- Name: COLUMN cad_produto.estoque_min; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.estoque_min IS 'Quantidade de estoque minimo';


--
-- Name: COLUMN cad_produto.curva_abc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.curva_abc IS 'Entra na curva abc de vendas';


--
-- Name: COLUMN cad_produto.carga_pdv; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.carga_pdv IS 'Envia carga para o pdv';


--
-- Name: COLUMN cad_produto.prod_balanca; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.prod_balanca IS 'Envia produto para balanca/ flag de produtos pesado';


--
-- Name: COLUMN cad_produto.permite_frac; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.permite_frac IS 'Permite venda fracionada';


--
-- Name: COLUMN cad_produto.permite_preco; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.permite_preco IS 'Permite alteracao de preco pelo pdv';


--
-- Name: COLUMN cad_produto.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.data_cadastro IS 'Data de cadastro do produto';


--
-- Name: COLUMN cad_produto.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_produto.data_altera IS 'Data de alteracao do produto';


--
-- Name: cad_produto_produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_produto_produto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_produto_produto_id_seq OWNER TO postgres;

--
-- Name: cad_produto_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_produto_produto_id_seq OWNED BY cad_produto.produto_id;


--
-- Name: cad_secao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_secao (
    secao_id smallint NOT NULL,
    descricao character varying(50) NOT NULL,
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_secao OWNER TO postgres;

--
-- Name: COLUMN cad_secao.secao_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_secao.secao_id IS 'chave primaria da secao';


--
-- Name: COLUMN cad_secao.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_secao.descricao IS 'Descricao da secao';


--
-- Name: COLUMN cad_secao.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_secao.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_secao.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_secao.data_altera IS 'Data de alteração';


--
-- Name: cad_secao_secao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_secao_secao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_secao_secao_id_seq OWNER TO postgres;

--
-- Name: cad_secao_secao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_secao_secao_id_seq OWNED BY cad_secao.secao_id;


--
-- Name: cad_subgrupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_subgrupo (
    subgrupo_id smallint NOT NULL,
    descricao character varying(50) NOT NULL,
    secao_id smallint NOT NULL,
    grupo_id smallint NOT NULL,
    data_cadastro date DEFAULT now() NOT NULL,
    data_altera date
);


ALTER TABLE cad_subgrupo OWNER TO postgres;

--
-- Name: COLUMN cad_subgrupo.subgrupo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.subgrupo_id IS 'Chave primaria do subgrupo';


--
-- Name: COLUMN cad_subgrupo.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.descricao IS 'Descrição do subgrupo';


--
-- Name: COLUMN cad_subgrupo.secao_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.secao_id IS 'Seção ao qual o subgrupo pertence';


--
-- Name: COLUMN cad_subgrupo.grupo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.grupo_id IS 'Grupo ao qual o subgrupo pergtence';


--
-- Name: COLUMN cad_subgrupo.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_subgrupo.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_subgrupo.data_altera IS 'Data de alteração';


--
-- Name: cad_subgrupo_subgrupo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_subgrupo_subgrupo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_subgrupo_subgrupo_id_seq OWNER TO postgres;

--
-- Name: cad_subgrupo_subgrupo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_subgrupo_subgrupo_id_seq OWNED BY cad_subgrupo.subgrupo_id;


--
-- Name: cad_unidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cad_unidade (
    unidade_id smallint NOT NULL,
    codigo character varying(10) NOT NULL,
    descricao character varying(20) NOT NULL,
    data_cadastro date NOT NULL,
    data_altera date
);


ALTER TABLE cad_unidade OWNER TO postgres;

--
-- Name: COLUMN cad_unidade.unidade_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_unidade.unidade_id IS 'Chave primaria';


--
-- Name: COLUMN cad_unidade.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_unidade.codigo IS 'Codigo da unidade';


--
-- Name: COLUMN cad_unidade.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_unidade.descricao IS 'Descriçao da unidade';


--
-- Name: COLUMN cad_unidade.data_cadastro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_unidade.data_cadastro IS 'Data de cadastro';


--
-- Name: COLUMN cad_unidade.data_altera; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN cad_unidade.data_altera IS 'Data de alteração';


--
-- Name: cad_unidade_unidade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cad_unidade_unidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cad_unidade_unidade_id_seq OWNER TO postgres;

--
-- Name: cad_unidade_unidade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cad_unidade_unidade_id_seq OWNED BY cad_unidade.unidade_id;


--
-- Name: plu_unidade; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE plu_unidade
    START WITH 1000000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plu_unidade OWNER TO postgres;

--
-- Name: tab_cest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cest (
    cest_id smallint NOT NULL,
    ncm character varying(10) NOT NULL,
    cest character(9) NOT NULL,
    descricao character varying(255) NOT NULL
);


ALTER TABLE tab_cest OWNER TO postgres;

--
-- Name: COLUMN tab_cest.cest_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cest.cest_id IS 'Chave primaria';


--
-- Name: COLUMN tab_cest.ncm; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cest.ncm IS 'Código ncm';


--
-- Name: COLUMN tab_cest.cest; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cest.cest IS 'Código cest';


--
-- Name: COLUMN tab_cest.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cest.descricao IS 'Descrição do codigo cest';


--
-- Name: tab_cest_cest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cest_cest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cest_cest_id_seq OWNER TO postgres;

--
-- Name: tab_cest_cest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cest_cest_id_seq OWNED BY tab_cest.cest_id;


--
-- Name: tab_cidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cidade (
    cidade_id smallint NOT NULL,
    codigo integer NOT NULL,
    cidade character varying(40) NOT NULL,
    uf smallint NOT NULL
);


ALTER TABLE tab_cidade OWNER TO postgres;

--
-- Name: COLUMN tab_cidade.cidade_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cidade.cidade_id IS 'Chave primária';


--
-- Name: COLUMN tab_cidade.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cidade.codigo IS 'Código da cidade';


--
-- Name: COLUMN tab_cidade.cidade; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cidade.cidade IS 'Nome da cidade';


--
-- Name: COLUMN tab_cidade.uf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cidade.uf IS 'Codigo do estado';


--
-- Name: tab_cidade_cidade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cidade_cidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cidade_cidade_id_seq OWNER TO postgres;

--
-- Name: tab_cidade_cidade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cidade_cidade_id_seq OWNED BY tab_cidade.cidade_id;


--
-- Name: tab_crt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_crt (
    crt_id smallint NOT NULL,
    codigo smallint NOT NULL,
    descricao character varying(40)
);


ALTER TABLE tab_crt OWNER TO postgres;

--
-- Name: COLUMN tab_crt.crt_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_crt.crt_id IS 'Chave primaria';


--
-- Name: COLUMN tab_crt.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_crt.codigo IS 'Codigo do regime tributário';


--
-- Name: COLUMN tab_crt.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_crt.descricao IS 'Nome do regime tributario';


--
-- Name: tab_crt_crt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_crt_crt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_crt_crt_id_seq OWNER TO postgres;

--
-- Name: tab_crt_crt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_crt_crt_id_seq OWNED BY tab_crt.crt_id;


--
-- Name: tab_csosn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_csosn (
    csosn_id integer NOT NULL,
    codigo character varying(3) NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE tab_csosn OWNER TO postgres;

--
-- Name: COLUMN tab_csosn.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_csosn.codigo IS 'Código de Tributação pelo CSOSN';


--
-- Name: COLUMN tab_csosn.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_csosn.descricao IS 'Descrição da tributação';


--
-- Name: tab_csosn_csosn_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_csosn_csosn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_csosn_csosn_id_seq OWNER TO postgres;

--
-- Name: tab_csosn_csosn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_csosn_csosn_id_seq OWNED BY tab_csosn.csosn_id;


--
-- Name: tab_cst_cofins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cst_cofins (
    cst_cofins_id smallint NOT NULL,
    codigo character(2) NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE tab_cst_cofins OWNER TO postgres;

--
-- Name: COLUMN tab_cst_cofins.cst_cofins_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_cofins.cst_cofins_id IS 'Chave primaria';


--
-- Name: COLUMN tab_cst_cofins.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_cofins.codigo IS 'Codigo do cst de cofins';


--
-- Name: COLUMN tab_cst_cofins.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_cofins.descricao IS 'Descrição do cst de cofins';


--
-- Name: tab_cst_cofins_cst_cofins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cst_cofins_cst_cofins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cst_cofins_cst_cofins_id_seq OWNER TO postgres;

--
-- Name: tab_cst_cofins_cst_cofins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cst_cofins_cst_cofins_id_seq OWNED BY tab_cst_cofins.cst_cofins_id;


--
-- Name: tab_cst_icms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cst_icms (
    cst_icms_id smallint NOT NULL,
    codigo character varying(3) NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE tab_cst_icms OWNER TO postgres;

--
-- Name: COLUMN tab_cst_icms.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_icms.codigo IS 'Código de Tributação pelo ICMS';


--
-- Name: COLUMN tab_cst_icms.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_icms.descricao IS 'Descrição da tributação';


--
-- Name: tab_cst_icms_cst_icms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cst_icms_cst_icms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cst_icms_cst_icms_id_seq OWNER TO postgres;

--
-- Name: tab_cst_icms_cst_icms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cst_icms_cst_icms_id_seq OWNED BY tab_cst_icms.cst_icms_id;


--
-- Name: tab_cst_ipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cst_ipi (
    cst_ipi_id smallint NOT NULL,
    codigo character(2) NOT NULL,
    descricao character varying(40) NOT NULL
);


ALTER TABLE tab_cst_ipi OWNER TO postgres;

--
-- Name: COLUMN tab_cst_ipi.cst_ipi_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_ipi.cst_ipi_id IS 'Chave primária';


--
-- Name: COLUMN tab_cst_ipi.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_ipi.codigo IS 'Código do cst de ipi';


--
-- Name: COLUMN tab_cst_ipi.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_ipi.descricao IS 'Descrição do cst de ipi';


--
-- Name: tab_cst_ipi_cst_ipi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cst_ipi_cst_ipi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cst_ipi_cst_ipi_id_seq OWNER TO postgres;

--
-- Name: tab_cst_ipi_cst_ipi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cst_ipi_cst_ipi_id_seq OWNED BY tab_cst_ipi.cst_ipi_id;


--
-- Name: tab_cst_pis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_cst_pis (
    cst_pis_id smallint NOT NULL,
    codigo character(2) NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE tab_cst_pis OWNER TO postgres;

--
-- Name: COLUMN tab_cst_pis.cst_pis_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_pis.cst_pis_id IS 'Chave primaria';


--
-- Name: COLUMN tab_cst_pis.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_pis.codigo IS 'Código do cst de pis';


--
-- Name: COLUMN tab_cst_pis.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_cst_pis.descricao IS 'Descrição do cst de pis';


--
-- Name: tab_cst_pis_cst_pis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_cst_pis_cst_pis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_cst_pis_cst_pis_id_seq OWNER TO postgres;

--
-- Name: tab_cst_pis_cst_pis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_cst_pis_cst_pis_id_seq OWNED BY tab_cst_pis.cst_pis_id;


--
-- Name: tab_estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_estado (
    estado_id smallint NOT NULL,
    codigo smallint NOT NULL,
    estado character varying(40) NOT NULL,
    uf character(2) NOT NULL
);


ALTER TABLE tab_estado OWNER TO postgres;

--
-- Name: COLUMN tab_estado.estado_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_estado.estado_id IS 'Chave primaria';


--
-- Name: COLUMN tab_estado.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_estado.codigo IS 'Código do estado';


--
-- Name: COLUMN tab_estado.estado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_estado.estado IS 'Nome do estado';


--
-- Name: COLUMN tab_estado.uf; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_estado.uf IS 'Unidade federal';


--
-- Name: tab_estado_estado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_estado_estado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_estado_estado_id_seq OWNER TO postgres;

--
-- Name: tab_estado_estado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_estado_estado_id_seq OWNED BY tab_estado.estado_id;


--
-- Name: tab_origem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_origem (
    origem_id smallint NOT NULL,
    codigo character varying(2),
    descricao character varying(50)
);


ALTER TABLE tab_origem OWNER TO postgres;

--
-- Name: COLUMN tab_origem.origem_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_origem.origem_id IS 'Chave primaria';


--
-- Name: COLUMN tab_origem.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_origem.codigo IS 'Origem da mercadoria';


--
-- Name: tab_origem_origem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_origem_origem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_origem_origem_id_seq OWNER TO postgres;

--
-- Name: tab_origem_origem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_origem_origem_id_seq OWNED BY tab_origem.origem_id;


--
-- Name: tab_tipo_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tab_tipo_produto (
    tipo_produto_id smallint NOT NULL,
    codigo smallint NOT NULL,
    descricao character varying(40) NOT NULL
);


ALTER TABLE tab_tipo_produto OWNER TO postgres;

--
-- Name: COLUMN tab_tipo_produto.tipo_produto_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_tipo_produto.tipo_produto_id IS 'Chave primaria';


--
-- Name: COLUMN tab_tipo_produto.codigo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_tipo_produto.codigo IS 'Código do tipo de produto';


--
-- Name: COLUMN tab_tipo_produto.descricao; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN tab_tipo_produto.descricao IS 'Descrição do tipo de produto';


--
-- Name: tab_tipo_produto_tipo_produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tab_tipo_produto_tipo_produto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tab_tipo_produto_tipo_produto_id_seq OWNER TO postgres;

--
-- Name: tab_tipo_produto_tipo_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tab_tipo_produto_tipo_produto_id_seq OWNED BY tab_tipo_produto.tipo_produto_id;


--
-- Name: album id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY album ALTER COLUMN id SET DEFAULT nextval('album_id_seq'::regclass);


--
-- Name: cad_cofins cofins_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_cofins ALTER COLUMN cofins_id SET DEFAULT nextval('cad_cofins_cofins_id_seq'::regclass);


--
-- Name: cad_ean sku_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ean ALTER COLUMN sku_id SET DEFAULT nextval('cad_ean_sku_id_seq'::regclass);


--
-- Name: cad_fornecedor fornecedor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_fornecedor ALTER COLUMN fornecedor_id SET DEFAULT nextval('cad_fornecedor_fornecedor_id_seq'::regclass);


--
-- Name: cad_grupo grupo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_grupo ALTER COLUMN grupo_id SET DEFAULT nextval('cad_grupo_grupo_id_seq'::regclass);


--
-- Name: cad_icms icms_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_icms ALTER COLUMN icms_id SET DEFAULT nextval('cad_icms_icms_id_seq'::regclass);


--
-- Name: cad_ipi ipi_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ipi ALTER COLUMN ipi_id SET DEFAULT nextval('cad_ipi_ipi_id_seq'::regclass);


--
-- Name: cad_loja loja_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_loja ALTER COLUMN loja_id SET DEFAULT nextval('cad_loja_loja_id_seq'::regclass);


--
-- Name: cad_ncm ncm_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ncm ALTER COLUMN ncm_id SET DEFAULT nextval('cad_ncm_ncm_id_seq'::regclass);


--
-- Name: cad_pis pis_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_pis ALTER COLUMN pis_id SET DEFAULT nextval('cad_pis_pis_id_seq'::regclass);


--
-- Name: cad_produto produto_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto ALTER COLUMN produto_id SET DEFAULT nextval('cad_produto_produto_id_seq'::regclass);


--
-- Name: cad_secao secao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_secao ALTER COLUMN secao_id SET DEFAULT nextval('cad_secao_secao_id_seq'::regclass);


--
-- Name: cad_subgrupo subgrupo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_subgrupo ALTER COLUMN subgrupo_id SET DEFAULT nextval('cad_subgrupo_subgrupo_id_seq'::regclass);


--
-- Name: cad_unidade unidade_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_unidade ALTER COLUMN unidade_id SET DEFAULT nextval('cad_unidade_unidade_id_seq'::regclass);


--
-- Name: tab_cest cest_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cest ALTER COLUMN cest_id SET DEFAULT nextval('tab_cest_cest_id_seq'::regclass);


--
-- Name: tab_cidade cidade_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cidade ALTER COLUMN cidade_id SET DEFAULT nextval('tab_cidade_cidade_id_seq'::regclass);


--
-- Name: tab_crt crt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_crt ALTER COLUMN crt_id SET DEFAULT nextval('tab_crt_crt_id_seq'::regclass);


--
-- Name: tab_csosn csosn_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_csosn ALTER COLUMN csosn_id SET DEFAULT nextval('tab_csosn_csosn_id_seq'::regclass);


--
-- Name: tab_cst_cofins cst_cofins_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_cofins ALTER COLUMN cst_cofins_id SET DEFAULT nextval('tab_cst_cofins_cst_cofins_id_seq'::regclass);


--
-- Name: tab_cst_icms cst_icms_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_icms ALTER COLUMN cst_icms_id SET DEFAULT nextval('tab_cst_icms_cst_icms_id_seq'::regclass);


--
-- Name: tab_cst_ipi cst_ipi_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_ipi ALTER COLUMN cst_ipi_id SET DEFAULT nextval('tab_cst_ipi_cst_ipi_id_seq'::regclass);


--
-- Name: tab_cst_pis cst_pis_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_pis ALTER COLUMN cst_pis_id SET DEFAULT nextval('tab_cst_pis_cst_pis_id_seq'::regclass);


--
-- Name: tab_estado estado_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_estado ALTER COLUMN estado_id SET DEFAULT nextval('tab_estado_estado_id_seq'::regclass);


--
-- Name: tab_origem origem_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_origem ALTER COLUMN origem_id SET DEFAULT nextval('tab_origem_origem_id_seq'::regclass);


--
-- Name: tab_tipo_produto tipo_produto_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_tipo_produto ALTER COLUMN tipo_produto_id SET DEFAULT nextval('tab_tipo_produto_tipo_produto_id_seq'::regclass);


--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY album (id, artist, title) FROM stdin;
\.
COPY album (id, artist, title) FROM '$$PATH$$/2428.dat';

--
-- Name: album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('album_id_seq', 5, true);


--
-- Data for Name: cad_cofins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_cofins (cofins_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_cofins (cofins_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM '$$PATH$$/2384.dat';

--
-- Name: cad_cofins_cofins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_cofins_cofins_id_seq', 6, true);


--
-- Data for Name: cad_ean; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_ean (sku_id, sku, plu_id, ativo, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_ean (sku_id, sku, plu_id, ativo, data_cadastro, data_altera) FROM '$$PATH$$/2386.dat';

--
-- Name: cad_ean_sku_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_ean_sku_id_seq', 65, true);


--
-- Data for Name: cad_fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_fornecedor (fornecedor_id, cnpj_cpf, ie_rg, ie_st, razao, fantasia, crt, cep, logradouro, numero, complemento, bairro, cidade, uf, contato, observacao, email, suframa, centro_custo_id, telefone, ramal, celular, ativo, data_cadastro, data_altera, tipo) FROM stdin;
\.
COPY cad_fornecedor (fornecedor_id, cnpj_cpf, ie_rg, ie_st, razao, fantasia, crt, cep, logradouro, numero, complemento, bairro, cidade, uf, contato, observacao, email, suframa, centro_custo_id, telefone, ramal, celular, ativo, data_cadastro, data_altera, tipo) FROM '$$PATH$$/2388.dat';

--
-- Name: cad_fornecedor_fornecedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_fornecedor_fornecedor_id_seq', 2, true);


--
-- Data for Name: cad_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_grupo (grupo_id, descricao, secao_id, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_grupo (grupo_id, descricao, secao_id, data_cadastro, data_altera) FROM '$$PATH$$/2390.dat';

--
-- Name: cad_grupo_grupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_grupo_grupo_id_seq', 20, true);


--
-- Data for Name: cad_icms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_icms (icms_id, cst, descricao, tributacao, csosn, origem, aliquota, base, mod_icms, aliquota_st, base_st, mod_icms_st, uso, texto_nf_id, cod_tributacao_pdv, cfop, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_icms (icms_id, cst, descricao, tributacao, csosn, origem, aliquota, base, mod_icms, aliquota_st, base_st, mod_icms_st, uso, texto_nf_id, cod_tributacao_pdv, cfop, data_cadastro, data_altera) FROM '$$PATH$$/2392.dat';

--
-- Name: cad_icms_icms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_icms_icms_id_seq', 12, true);


--
-- Data for Name: cad_ipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_ipi (ipi_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_ipi (ipi_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM '$$PATH$$/2394.dat';

--
-- Name: cad_ipi_ipi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_ipi_ipi_id_seq', 5, true);


--
-- Data for Name: cad_loja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_loja (loja_id, razao, fantasia, cnpj, ie, telefone, logradouro, numero, bairro, municipio, cep, estado, num_loja, mix, crt, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_loja (loja_id, razao, fantasia, cnpj, ie, telefone, logradouro, numero, bairro, municipio, cep, estado, num_loja, mix, crt, data_cadastro, data_altera) FROM '$$PATH$$/2396.dat';

--
-- Name: cad_loja_loja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_loja_loja_id_seq', 1, false);


--
-- Data for Name: cad_ncm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_ncm (codigo, descricao, ex_tipi, nat, pis_entrada_id, pis_saida_id, cofins_entrada_id, cofins_saida_id, icms_pdv_id, icms_nf_entrada_id, icms_nf_saida_id, ipi_entrada_id, ipi_saida_id, mva_st, data_cadastro, data_altera, cest_id, ncm, ncm_id) FROM stdin;
\.
COPY cad_ncm (codigo, descricao, ex_tipi, nat, pis_entrada_id, pis_saida_id, cofins_entrada_id, cofins_saida_id, icms_pdv_id, icms_nf_entrada_id, icms_nf_saida_id, ipi_entrada_id, ipi_saida_id, mva_st, data_cadastro, data_altera, cest_id, ncm, ncm_id) FROM '$$PATH$$/2398.dat';

--
-- Name: cad_ncm_ncm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_ncm_ncm_id_seq', 19, true);


--
-- Data for Name: cad_pis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_pis (pis_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_pis (pis_id, codigo, descricao, aliquota, data_cadastro, data_altera) FROM '$$PATH$$/2399.dat';

--
-- Name: cad_pis_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_pis_pis_id_seq', 5, true);


--
-- Data for Name: cad_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_produto (produto_id, plu, sku_id, ativo, descricao, desc_resumida, ncm_id, secao_id, grupo_id, subgrupo_id, fornecedor_id, grade_id, embalagem_id, unidade_id, tipo_produto_id, icms_nf_entrada_id, icms_nf_saida_id, icms_pdv_id, pis_entrada_id, pis_saida_id, cofins_entrada_id, cofins_saida_id, ipi_entrada_id, ipi_saida_id, mva_st, peso_liquido, peso_bruto, estoque_min, estoque_ideal, curva_abc, carga_pdv, prod_balanca, permite_frac, permite_preco, data_cadastro, cest_id, cod_fornecedor, ref_fornecedor, data_altera) FROM stdin;
\.
COPY cad_produto (produto_id, plu, sku_id, ativo, descricao, desc_resumida, ncm_id, secao_id, grupo_id, subgrupo_id, fornecedor_id, grade_id, embalagem_id, unidade_id, tipo_produto_id, icms_nf_entrada_id, icms_nf_saida_id, icms_pdv_id, pis_entrada_id, pis_saida_id, cofins_entrada_id, cofins_saida_id, ipi_entrada_id, ipi_saida_id, mva_st, peso_liquido, peso_bruto, estoque_min, estoque_ideal, curva_abc, carga_pdv, prod_balanca, permite_frac, permite_preco, data_cadastro, cest_id, cod_fornecedor, ref_fornecedor, data_altera) FROM '$$PATH$$/2433.dat';

--
-- Name: cad_produto_produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_produto_produto_id_seq', 73, true);


--
-- Data for Name: cad_secao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_secao (secao_id, descricao, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_secao (secao_id, descricao, data_cadastro, data_altera) FROM '$$PATH$$/2401.dat';

--
-- Name: cad_secao_secao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_secao_secao_id_seq', 108, true);


--
-- Data for Name: cad_subgrupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_subgrupo (subgrupo_id, descricao, secao_id, grupo_id, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_subgrupo (subgrupo_id, descricao, secao_id, grupo_id, data_cadastro, data_altera) FROM '$$PATH$$/2403.dat';

--
-- Name: cad_subgrupo_subgrupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_subgrupo_subgrupo_id_seq', 10, true);


--
-- Data for Name: cad_unidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cad_unidade (unidade_id, codigo, descricao, data_cadastro, data_altera) FROM stdin;
\.
COPY cad_unidade (unidade_id, codigo, descricao, data_cadastro, data_altera) FROM '$$PATH$$/2405.dat';

--
-- Name: cad_unidade_unidade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cad_unidade_unidade_id_seq', 3, true);


--
-- Name: plu_unidade; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('plu_unidade', 1000067, true);


--
-- Data for Name: tab_cest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cest (cest_id, ncm, cest, descricao) FROM stdin;
\.
COPY tab_cest (cest_id, ncm, cest, descricao) FROM '$$PATH$$/2407.dat';

--
-- Name: tab_cest_cest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cest_cest_id_seq', 1, true);


--
-- Data for Name: tab_cidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cidade (cidade_id, codigo, cidade, uf) FROM stdin;
\.
COPY tab_cidade (cidade_id, codigo, cidade, uf) FROM '$$PATH$$/2409.dat';

--
-- Name: tab_cidade_cidade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cidade_cidade_id_seq', 3, true);


--
-- Data for Name: tab_crt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_crt (crt_id, codigo, descricao) FROM stdin;
\.
COPY tab_crt (crt_id, codigo, descricao) FROM '$$PATH$$/2411.dat';

--
-- Name: tab_crt_crt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_crt_crt_id_seq', 4, true);


--
-- Data for Name: tab_csosn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_csosn (csosn_id, codigo, descricao) FROM stdin;
\.
COPY tab_csosn (csosn_id, codigo, descricao) FROM '$$PATH$$/2430.dat';

--
-- Name: tab_csosn_csosn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_csosn_csosn_id_seq', 2, true);


--
-- Data for Name: tab_cst_cofins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cst_cofins (cst_cofins_id, codigo, descricao) FROM stdin;
\.
COPY tab_cst_cofins (cst_cofins_id, codigo, descricao) FROM '$$PATH$$/2413.dat';

--
-- Name: tab_cst_cofins_cst_cofins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cst_cofins_cst_cofins_id_seq', 5, true);


--
-- Data for Name: tab_cst_icms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cst_icms (cst_icms_id, codigo, descricao) FROM stdin;
\.
COPY tab_cst_icms (cst_icms_id, codigo, descricao) FROM '$$PATH$$/2415.dat';

--
-- Name: tab_cst_icms_cst_icms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cst_icms_cst_icms_id_seq', 3, true);


--
-- Data for Name: tab_cst_ipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cst_ipi (cst_ipi_id, codigo, descricao) FROM stdin;
\.
COPY tab_cst_ipi (cst_ipi_id, codigo, descricao) FROM '$$PATH$$/2417.dat';

--
-- Name: tab_cst_ipi_cst_ipi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cst_ipi_cst_ipi_id_seq', 3, true);


--
-- Data for Name: tab_cst_pis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_cst_pis (cst_pis_id, codigo, descricao) FROM stdin;
\.
COPY tab_cst_pis (cst_pis_id, codigo, descricao) FROM '$$PATH$$/2419.dat';

--
-- Name: tab_cst_pis_cst_pis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_cst_pis_cst_pis_id_seq', 1, false);


--
-- Data for Name: tab_estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_estado (estado_id, codigo, estado, uf) FROM stdin;
\.
COPY tab_estado (estado_id, codigo, estado, uf) FROM '$$PATH$$/2421.dat';

--
-- Name: tab_estado_estado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_estado_estado_id_seq', 1, true);


--
-- Data for Name: tab_origem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_origem (origem_id, codigo, descricao) FROM stdin;
\.
COPY tab_origem (origem_id, codigo, descricao) FROM '$$PATH$$/2423.dat';

--
-- Name: tab_origem_origem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_origem_origem_id_seq', 3, true);


--
-- Data for Name: tab_tipo_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tab_tipo_produto (tipo_produto_id, codigo, descricao) FROM stdin;
\.
COPY tab_tipo_produto (tipo_produto_id, codigo, descricao) FROM '$$PATH$$/2425.dat';

--
-- Name: tab_tipo_produto_tipo_produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tab_tipo_produto_tipo_produto_id_seq', 1, true);


--
-- Name: cad_secao Attribute1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_secao
    ADD CONSTRAINT "Attribute1" UNIQUE (descricao);


--
-- Name: cad_cofins Attribute2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_cofins
    ADD CONSTRAINT "Attribute2" UNIQUE (descricao);


--
-- Name: cad_pis Attribute21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_pis
    ADD CONSTRAINT "Attribute21" UNIQUE (descricao);


--
-- Name: cad_cofins PK_cad_cofins; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_cofins
    ADD CONSTRAINT "PK_cad_cofins" PRIMARY KEY (cofins_id);


--
-- Name: tab_crt PK_cad_crt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_crt
    ADD CONSTRAINT "PK_cad_crt" PRIMARY KEY (crt_id);


--
-- Name: cad_ean PK_cad_ean; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ean
    ADD CONSTRAINT "PK_cad_ean" PRIMARY KEY (sku_id);


--
-- Name: cad_fornecedor PK_cad_fornecedor; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_fornecedor
    ADD CONSTRAINT "PK_cad_fornecedor" PRIMARY KEY (fornecedor_id);


--
-- Name: cad_grupo PK_cad_grupo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_grupo
    ADD CONSTRAINT "PK_cad_grupo" PRIMARY KEY (grupo_id, secao_id);


--
-- Name: cad_icms PK_cad_icms_nf; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_icms
    ADD CONSTRAINT "PK_cad_icms_nf" PRIMARY KEY (icms_id);


--
-- Name: cad_ipi PK_cad_ipi; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ipi
    ADD CONSTRAINT "PK_cad_ipi" PRIMARY KEY (ipi_id);


--
-- Name: cad_loja PK_cad_loja; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_loja
    ADD CONSTRAINT "PK_cad_loja" PRIMARY KEY (loja_id);


--
-- Name: cad_pis PK_cad_pis; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_pis
    ADD CONSTRAINT "PK_cad_pis" PRIMARY KEY (pis_id);


--
-- Name: cad_secao PK_cad_secao; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_secao
    ADD CONSTRAINT "PK_cad_secao" PRIMARY KEY (secao_id);


--
-- Name: cad_subgrupo PK_cad_subgrupo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_subgrupo
    ADD CONSTRAINT "PK_cad_subgrupo" PRIMARY KEY (subgrupo_id, secao_id, grupo_id);


--
-- Name: tab_tipo_produto PK_cad_tipo_produto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_tipo_produto
    ADD CONSTRAINT "PK_cad_tipo_produto" PRIMARY KEY (tipo_produto_id);


--
-- Name: cad_unidade PK_cad_unidade; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_unidade
    ADD CONSTRAINT "PK_cad_unidade" PRIMARY KEY (unidade_id);


--
-- Name: tab_cest PK_tab_cest; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cest
    ADD CONSTRAINT "PK_tab_cest" PRIMARY KEY (cest_id);


--
-- Name: tab_cidade PK_tab_cidade; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cidade
    ADD CONSTRAINT "PK_tab_cidade" PRIMARY KEY (cidade_id);


--
-- Name: tab_csosn PK_tab_csosn; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_csosn
    ADD CONSTRAINT "PK_tab_csosn" PRIMARY KEY (csosn_id);


--
-- Name: tab_cst_cofins PK_tab_cst_cofins; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_cofins
    ADD CONSTRAINT "PK_tab_cst_cofins" PRIMARY KEY (cst_cofins_id);


--
-- Name: tab_cst_icms PK_tab_cst_icms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_icms
    ADD CONSTRAINT "PK_tab_cst_icms" PRIMARY KEY (cst_icms_id);


--
-- Name: tab_cst_ipi PK_tab_cst_ipi; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_ipi
    ADD CONSTRAINT "PK_tab_cst_ipi" PRIMARY KEY (cst_ipi_id);


--
-- Name: tab_cst_pis PK_tab_cst_pis; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_cst_pis
    ADD CONSTRAINT "PK_tab_cst_pis" PRIMARY KEY (cst_pis_id);


--
-- Name: tab_estado PK_tab_estado; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_estado
    ADD CONSTRAINT "PK_tab_estado" PRIMARY KEY (estado_id);


--
-- Name: tab_origem PK_tab_origem; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_origem
    ADD CONSTRAINT "PK_tab_origem" PRIMARY KEY (origem_id);


--
-- Name: cad_ncm cad_ncm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ncm
    ADD CONSTRAINT cad_ncm_pkey PRIMARY KEY (ncm_id);


--
-- Name: cad_produto cad_produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_produto_pkey PRIMARY KEY (produto_id);


--
-- Name: cad_pis codigo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_pis
    ADD CONSTRAINT codigo UNIQUE (codigo);


--
-- Name: tab_tipo_produto codigo1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_tipo_produto
    ADD CONSTRAINT codigo1 UNIQUE (codigo);


--
-- Name: cad_cofins codigo12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_cofins
    ADD CONSTRAINT codigo12 UNIQUE (codigo);


--
-- Name: cad_unidade codigo31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_unidade
    ADD CONSTRAINT codigo31 UNIQUE (codigo);


--
-- Name: tab_tipo_produto descricao; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tab_tipo_produto
    ADD CONSTRAINT descricao UNIQUE (descricao);


--
-- Name: cad_unidade descricao1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_unidade
    ADD CONSTRAINT descricao1 UNIQUE (descricao);


--
-- Name: cad_icms descricao11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_icms
    ADD CONSTRAINT descricao11 UNIQUE (descricao);


--
-- Name: cad_ean sku; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_ean
    ADD CONSTRAINT sku UNIQUE (sku);


--
-- Name: cad_produto cad_cofins_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_cofins_cad_produto FOREIGN KEY (cofins_entrada_id) REFERENCES cad_cofins(cofins_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_cofins_cad_produto_15; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_cofins_cad_produto_15 FOREIGN KEY (cofins_saida_id) REFERENCES cad_cofins(cofins_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_ean_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_ean_cad_produto FOREIGN KEY (sku_id) REFERENCES cad_ean(sku_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_fornecedor_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_fornecedor_cad_produto FOREIGN KEY (fornecedor_id) REFERENCES cad_fornecedor(fornecedor_id) ON DELETE RESTRICT;


--
-- Name: cad_subgrupo cad_grupo_cad_subgrupo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_subgrupo
    ADD CONSTRAINT cad_grupo_cad_subgrupo FOREIGN KEY (grupo_id, secao_id) REFERENCES cad_grupo(grupo_id, secao_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_icms_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_icms_cad_produto FOREIGN KEY (icms_nf_saida_id) REFERENCES cad_icms(icms_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_icms_cad_produto_6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_icms_cad_produto_6 FOREIGN KEY (icms_pdv_id) REFERENCES cad_icms(icms_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_icms_cad_produto_8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_icms_cad_produto_8 FOREIGN KEY (icms_nf_entrada_id) REFERENCES cad_icms(icms_id);


--
-- Name: cad_produto cad_ipi_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_ipi_cad_produto FOREIGN KEY (ipi_entrada_id) REFERENCES cad_ipi(ipi_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_ipi_cad_produto_16; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_ipi_cad_produto_16 FOREIGN KEY (ipi_saida_id) REFERENCES cad_ipi(ipi_id) ON DELETE RESTRICT;


--
-- Name: cad_grupo cad_secao_cad_grupo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_grupo
    ADD CONSTRAINT cad_secao_cad_grupo FOREIGN KEY (secao_id) REFERENCES cad_secao(secao_id) ON DELETE CASCADE;


--
-- Name: cad_produto cad_subgrupo_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_subgrupo_cad_produto FOREIGN KEY (subgrupo_id, secao_id, grupo_id) REFERENCES cad_subgrupo(subgrupo_id, secao_id, grupo_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_tipo_produto_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_tipo_produto_cad_produto FOREIGN KEY (tipo_produto_id) REFERENCES tab_tipo_produto(tipo_produto_id) ON DELETE RESTRICT;


--
-- Name: cad_produto cad_unidade_cad_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cad_produto
    ADD CONSTRAINT cad_unidade_cad_produto FOREIGN KEY (unidade_id) REFERENCES cad_unidade(unidade_id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

